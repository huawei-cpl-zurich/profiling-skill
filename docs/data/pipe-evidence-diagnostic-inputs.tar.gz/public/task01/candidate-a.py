import triton
import triton.language as tl

@triton.jit
def task_kernel(x, index, weight, coeff, output, WIDTH: tl.constexpr,
                ROUNDS: tl.constexpr, BLOCK: tl.constexpr):
    row = tl.program_id(0)
    col = tl.arange(0, BLOCK)
    address = tl.load(index + row * WIDTH + col, col < WIDTH, 0)
    value = tl.load(x + address, col < WIDTH, 0)
    w = tl.load(weight + row * WIDTH + col, col < WIDTH, 0)
    for step in range(ROUNDS):
        a = tl.load(coeff + step * 2)
        b = tl.load(coeff + step * 2 + 1)
        value = value + a * (2.0 / (1.0 + tl.exp(-(value * b))) - 1.0)
    mean = tl.sum(tl.where(col < WIDTH, value * w, 0), 0) / WIDTH
    energy = tl.sum(tl.where(col < WIDTH, value * value * w, 0), 0) / WIDTH
    tl.store(output + row * 2, mean)
    tl.store(output + row * 2 + 1, energy)

def launch(inputs, output):
    return task_kernel[(output.shape[0],)](
        inputs['x'], inputs['index'], inputs['weight'], inputs['coeff'], output,
        inputs['index'].shape[1], inputs['coeff'].shape[0], 256, num_warps=8)

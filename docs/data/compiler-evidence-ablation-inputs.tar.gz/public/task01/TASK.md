Return x[index[i]] for every output position i. Runtime indices may contain any valid input positions, including repeats. The qualification input uses contiguous runtime indices; do not specialize away the lookup contract.

Compare the two proposed source changes. Only baseline performance observations are supplied. Compiler evidence, when available, covers all three implementations.

#!/usr/bin/env python3
"""Standalone correctness/capture workload; one compute launch per invocation."""
import argparse
import hashlib
import json
from pathlib import Path
import tempfile

BK = 64
OPTIONS = {'num_stages': 1}


def reference(a, b):
    return a.float() @ b.float()


def build_kernel():
    global triton, tl
    import triton
    import triton.language as tl

    @triton.jit
    def a3_memory_probe(a, b, out, M: tl.constexpr, N: tl.constexpr, K: tl.constexpr,
                        BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr):
        m = tl.program_id(0) * BM + tl.arange(0, BM)
        n = tl.program_id(1) * BN + tl.arange(0, BN)
        k = tl.arange(0, BK)
        acc = tl.full((BM, BN), 0., tl.float32)
        for step in range(triton.cdiv(K, BK)):
            kk = step * BK + k
            av = tl.load(a + m[:, None] * K + kk[None, :],
                         (m[:, None] < M) & (kk[None, :] < K), other=0.)
            bv = tl.load(b + kk[:, None] * N + n[None, :],
                         (kk[:, None] < K) & (n[None, :] < N), other=0.)
            acc += tl.dot(av, bv)
        tl.store(out + m[:, None] * N + n[None, :], acc,
                 (m[:, None] < M) & (n[None, :] < N))
    return a3_memory_probe


def run(root, cpu_check=False):
    import torch
    torch.manual_seed(0)
    cpu_a = torch.randn((128, 512), dtype=torch.float16)
    cpu_b = torch.randn((512, 128), dtype=torch.float16)
    expected = reference(cpu_a, cpu_b)
    specialization = dict(M=128, N=128, K=512, BM=32, BN=64, BK=BK)
    if cpu_check:
        assert expected.shape == (128, 128) and expected.dtype == torch.float32
        return dict(correctness=True, cpu_only=True, specialization=specialization, options=OPTIONS)
    import torch_npu
    import triton
    kernel = build_kernel()
    a, b = cpu_a.npu(), cpu_b.npu()
    out = torch.empty((128, 128), device='npu', dtype=torch.float32)
    compiled = kernel[(4, 2)](a, b, out, **specialization, **OPTIONS)
    torch.npu.synchronize()
    torch.testing.assert_close(out.cpu(), expected, atol=0.05, rtol=0.01)
    output, result = retain(compiled, triton, root, specialization, OPTIONS)
    result.update(correctness=True, torch_version=torch.__version__,
                  device_name=torch.npu.get_device_name(0), artifact_directory=str(output))
    (output / 'runtime.json').write_text(json.dumps(result, indent=2) + '\n')
    return result

def retain(compiled, triton, root, specialization, options):
    root = Path(root)
    root.mkdir(parents=True, exist_ok=True)
    output = Path(tempfile.mkdtemp(prefix='invocation-', dir=root))
    artifacts = []
    omitted = []
    for stage, value in compiled.asm.items():
        if not isinstance(value, (str, bytes)):
            omitted.append({'stage': stage, 'type': type(value).__name__})
            continue
        if Path(stage).name != stage:
            raise ValueError('invalid compiler stage filename')
        data = value.encode() if isinstance(value, str) else value
        path = output / (stage + ('.txt' if isinstance(value, str) else '.bin'))
        path.write_bytes(data)
        artifacts.append({'stage': stage, 'path': str(path),
                          'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)})
    metadata = str(compiled.metadata)
    target = str(triton.runtime.driver.active.get_current_target())
    metadata_path = output / 'compiler-metadata.txt'
    metadata_path.write_text(metadata)
    target_path = output / 'target.txt'
    target_path.write_text(target)
    return output, dict(artifacts=artifacts, omitted_asm_types=omitted,
        compiler_metadata=metadata,
        compiler_metadata_sha256=hashlib.sha256(metadata_path.read_bytes()).hexdigest(),
        target=target, target_sha256=hashlib.sha256(target_path.read_bytes()).hexdigest(),
        triton_version=triton.__version__,
        source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        specialization=specialization, options=options)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--artifacts', type=Path, required=True)
    parser.add_argument('--cpu-check', action='store_true')
    args = parser.parse_args()
    result = run(args.artifacts, cpu_check=args.cpu_check)
    print(json.dumps(result), flush=True)
    return 0 if result['correctness'] else 1


if __name__ == '__main__':
    raise SystemExit(main())


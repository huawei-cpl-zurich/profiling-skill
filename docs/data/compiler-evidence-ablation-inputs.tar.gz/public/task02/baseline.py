#!/usr/bin/env python3
"""Standalone correctness/capture workload; one compute launch per invocation."""
import argparse
import hashlib
import json
from pathlib import Path
import tempfile

BLOCK = 1024
PREDICATE = False
N = 1 << 20


def reference(source):
    import torch
    return torch.where(torch.arange(source.numel()) % 4 == 0, source, 0.)


def build_kernel():
    global tl
    import triton
    import triton.language as tl

    @triton.jit
    def a3_memory_probe(x, out, N: tl.constexpr, PREDICATE: tl.constexpr, BLOCK: tl.constexpr):
        i = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
        selected = i % 4 == 0
        if PREDICATE:
            value = tl.load(x + i, (i < N) & selected, other=0)
        else:
            value = tl.load(x + i, i < N, other=0)
            value = tl.where(selected, value, 0.)
        tl.store(out + i, value, i < N)
    return a3_memory_probe


def run(root, cpu_check=False):
    import torch
    torch.manual_seed(0)
    source = torch.randn(N, dtype=torch.float32)
    expected = reference(source)
    specialization = dict(N=N, PREDICATE=PREDICATE, BLOCK=BLOCK)
    options = {}
    if cpu_check:
        torch.testing.assert_close(reference(torch.tensor([1., 2., 3., 4., 5.])),
                                   torch.tensor([1., 0., 0., 0., 5.]))
        return dict(correctness=True, cpu_only=True, specialization=specialization, options=options)
    import torch_npu
    import triton
    kernel = build_kernel()
    x = source.npu()
    out = torch.empty(N, device='npu', dtype=torch.float32)
    compiled = kernel[(triton.cdiv(N, BLOCK),)](x, out, **specialization)
    torch.npu.synchronize()
    torch.testing.assert_close(out.cpu(), expected, rtol=0, atol=0)
    output, result = retain(compiled, triton, root, specialization, options)
    result.update(correctness=True, torch_version=torch.__version__,
                  device_name=torch.npu.get_device_name(0), artifact_directory=str(output))
    (output / 'runtime.json').write_text(json.dumps(result, indent=2) + '\n')
    return result

def retain(compiled, triton, root, specialization, options):
    root = Path(root)
    root.mkdir(parents=True, exist_ok=True)
    output = Path(tempfile.mkdtemp(prefix='invocation-', dir=root))
    artifacts = []
    omitted = []
    for stage, value in compiled.asm.items():
        if not isinstance(value, (str, bytes)):
            omitted.append({'stage': stage, 'type': type(value).__name__})
            continue
        if Path(stage).name != stage:
            raise ValueError('invalid compiler stage filename')
        data = value.encode() if isinstance(value, str) else value
        path = output / (stage + ('.txt' if isinstance(value, str) else '.bin'))
        path.write_bytes(data)
        artifacts.append({'stage': stage, 'path': str(path),
                          'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)})
    metadata = str(compiled.metadata)
    target = str(triton.runtime.driver.active.get_current_target())
    metadata_path = output / 'compiler-metadata.txt'
    metadata_path.write_text(metadata)
    target_path = output / 'target.txt'
    target_path.write_text(target)
    return output, dict(artifacts=artifacts, omitted_asm_types=omitted,
        compiler_metadata=metadata,
        compiler_metadata_sha256=hashlib.sha256(metadata_path.read_bytes()).hexdigest(),
        target=target, target_sha256=hashlib.sha256(target_path.read_bytes()).hexdigest(),
        triton_version=triton.__version__,
        source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        specialization=specialization, options=options)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--artifacts', type=Path, required=True)
    parser.add_argument('--cpu-check', action='store_true')
    args = parser.parse_args()
    result = run(args.artifacts, cpu_check=args.cpu_check)
    print(json.dumps(result), flush=True)
    return 0 if result['correctness'] else 1


if __name__ == '__main__':
    raise SystemExit(main())


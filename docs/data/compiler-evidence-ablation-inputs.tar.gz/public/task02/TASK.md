Return x[i] when i modulo 4 equals zero, otherwise zero, for every input position. Preserve fp32 values and the full output shape.

Compare the two proposed source changes. Only baseline performance observations are supplied. Compiler evidence, when available, covers all three implementations.

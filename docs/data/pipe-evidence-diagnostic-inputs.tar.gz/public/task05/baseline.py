import triton
import triton.language as tl

@triton.jit
def task_kernel(lhs, rhs, bias, residual, coeff, output, M: tl.constexpr,
                N: tl.constexpr, K: tl.constexpr, ROUNDS: tl.constexpr,
                BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr):
    rows = tl.program_id(0) * BM + tl.arange(0, BM)
    cols = tl.program_id(1) * BN + tl.arange(0, BN)
    inner = tl.arange(0, BK)
    acc = tl.full((BM, BN), 0, tl.float32)
    for base in range(tl.cdiv(K, BK)):
        kk = base * BK + inner
        a = tl.load(lhs + rows[:, None] * K + kk[None, :],
                    (rows[:, None] < M) & (kk[None, :] < K), 0)
        b = tl.load(rhs + kk[:, None] * N + cols[None, :],
                    (kk[:, None] < K) & (cols[None, :] < N), 0)
        acc = tl.dot(a, b, acc)
    value = acc + tl.load(bias + cols, cols < N, 0)[None, :]
    for step in range(ROUNDS):
        a = tl.load(coeff + step * 2)
        b = tl.load(coeff + step * 2 + 1)
        value = value + a * (2.0 / (1.0 + tl.exp(-value * b)) - 1.0)
    skip = tl.load(residual + rows[:, None] * N + cols[None, :],
                   (rows[:, None] < M) & (cols[None, :] < N), 0)
    value = skip + value / (1.0 + tl.exp(-value))
    tl.store(output + rows[:, None] * N + cols[None, :], value,
             (rows[:, None] < M) & (cols[None, :] < N))

def launch(inputs, output):
    return task_kernel[(triton.cdiv(output.shape[0], 32), triton.cdiv(output.shape[1], 64))](
        inputs['lhs'], inputs['rhs'], inputs['bias'], inputs['residual'], inputs['coeff'],
        output, output.shape[0], output.shape[1], inputs['lhs'].shape[1],
        inputs['coeff'].shape[0], 32, 64, 32, num_warps=4)

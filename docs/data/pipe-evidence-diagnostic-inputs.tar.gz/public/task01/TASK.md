Analyze the baseline and two proposed source changes for this task.
The baseline implements launch(inputs, output) in a single fused Triton kernel.
Preserve every input-dependent stage, output shape and declared tolerances.
Inputs may be arbitrary finite normal values; gather indices and masks may be arbitrary valid values.
task.json gives the shape and input contract; baseline.py is the executable specification.
candidate-a.py and candidate-b.py are proposed alternatives, not measured winners.
timing.json contains baseline measurements only. This is a diagnostic task, not a request to run kernels.

Compute the matrix product of fp16 A[M,K] and B[K,N], accumulating and returning fp32. Qualification dimensions are M=128,N=128,K=512. Preserve masking and the provided interface.

Compare the two proposed source changes. Only baseline performance observations are supplied. Compiler evidence, when available, covers all three implementations.

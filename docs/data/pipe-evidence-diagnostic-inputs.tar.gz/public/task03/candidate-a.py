import triton
import triton.language as tl

@triton.jit
def task_kernel(x, selected, gain, output, WIDTH: tl.constexpr, BLOCK: tl.constexpr):
    row = tl.program_id(0)
    col = tl.arange(0, BLOCK)
    valid = col < WIDTH
    keep = tl.load(selected + row * WIDTH + col, valid, 0).to(tl.int1)
    value = tl.load(x + row * WIDTH + col, valid & keep, 0)
    scale = tl.load(gain + col, valid, 0)
    score = value * (2.0 / (1.0 + tl.exp(-value * scale)) - 1.0)
    score = tl.where(valid & keep, score, -float('inf'))
    maximum = tl.max(score, 0)
    maximum = tl.where(maximum == -float('inf'), 0.0, maximum)
    probability = tl.exp(score - maximum)
    denominator = tl.sum(probability, 0)
    result = probability / tl.maximum(denominator, 1.0e-20)
    tl.store(output + row * WIDTH + col, result, valid)

def launch(inputs, output):
    return task_kernel[(output.shape[0],)](
        inputs['x'], inputs['selected'], inputs['gain'], output,
        output.shape[1], triton.next_power_of_2(output.shape[1]), num_warps=4)
